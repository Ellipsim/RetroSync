package com.retrosync.saves;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SaveServiceApplicationTests {

	@Test
	void contextLoads() {
	}

}
